import pandas as pd
from sqlalchemy import create_engine
import urllib

def upload_csv_to_db(file_table_mapping, custom_headers=None, batch_size=1000):
    if custom_headers is None:
        custom_headers = {}

    # Configuración de la base de datos
    DATABASE_CONFIG = {
        'Server': 'SANTIOC\BDSANTI',
        'Database': 'Globantest',
        'Trusted_Connection': 'yes'  #  autenticación de Windows
    }

    # Creo la cadena de conexión
    conn_str = (
        r'DRIVER={ODBC Driver 17 for SQL Server};'
        rf'SERVER={DATABASE_CONFIG["Server"]};'
        rf'DATABASE={DATABASE_CONFIG["Database"]};'
        rf'Trusted_Connection={DATABASE_CONFIG["Trusted_Connection"]};'
    )

    # Codificar la cadena de conexión
    quoted_conn_str = urllib.parse.quote_plus(conn_str)

    # Creo la conexión al motor SQLAlchemy
    engine = create_engine("mssql+pyodbc:///?odbc_connect={}".format(quoted_conn_str))

    # Iterar sobre los archivos y tablas
    for file_path, table_name in file_table_mapping:
        # Leer el archivo CSV en un DataFrame
        df = pd.read_csv(file_path)

        # Verificar si hay encabezados personalizados para esta tabla
        if table_name in custom_headers:
            headers = custom_headers[table_name]
            df.columns = headers

        # Dividir el DataFrame en lotes y cargarlos en la base de datos
        for i in range(0, len(df), batch_size):
            batch_df = df.iloc[i:i+batch_size]
            batch_df.to_sql(table_name, engine, if_exists='append', index=False)

    return True

# Definir los archivos CSV y los nombres de las tablas 
file_table_mapping = [
    (r'C:\Users\USER\OneDrive\Escritorio\Uploads\departments.csv', 'departments'),
    (r'C:\Users\USER\OneDrive\Escritorio\Uploads\hired_employees.csv', 'hired_employees'),
    (r'C:\Users\USER\OneDrive\Escritorio\Uploads\jobs.csv', 'jobs')
]

# Definir los encabezados personalizados para cada tabla 
custom_headers = {
    'departments': ['ID', 'Department'],  
    'hired_employees': ['ID', 'Name', 'Datetime', 'Department_id','Job_id'],  
    'jobs': ['ID', 'Job']  
}

# Llamar a la función para la carga de los CSVs en la base de datos
upload_csv_to_db(file_table_mapping, custom_headers)