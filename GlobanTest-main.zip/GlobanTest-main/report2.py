import pandas as pd
from sqlalchemy import create_engine

def generate_department_hiring_report(DATABASE_CONFIG):
    # Creo la cadena de conexión
    conn_str = (
        f"mssql+pyodbc://{DATABASE_CONFIG['Server']}/{DATABASE_CONFIG['Database']}?"
        f"trusted_connection={DATABASE_CONFIG['Trusted_Connection']}&"
        "driver=ODBC+Driver+17+for+SQL+Server"
    )

    # Creo la conexión al motor SQLAlchemy
    engine = create_engine(conn_str)

    # Definir la consulta SQL para generar el informe de contratación por departamento
    sql_query = """
        WITH DepartmentHiring AS (
            SELECT
                Department_id,
                COUNT(*) AS Hired
            FROM
                hired_employees
            WHERE
                hired_employees.Datetime >= '2021-01-01' AND hired_employees.Datetime < '2022-01-01'
            GROUP BY
                Department_id
        ),
        MeanHiring AS (
            SELECT
                AVG(Hired) AS MeanHired
            FROM
                DepartmentHiring
        )
        SELECT
            d.ID AS id,
            d.Department AS department,
            dh.Hired AS hired
        FROM
            DepartmentHiring dh
        INNER JOIN
            departments d ON dh.Department_id = d.ID
        INNER JOIN
            MeanHiring mh ON 1=1
        WHERE
            dh.Hired > mh.MeanHired
        ORDER BY
            dh.Hired DESC
    """

    # Ejecutar la consulta SQL y almacenar los resultados en un DataFrame
    result_df = pd.read_sql_query(sql_query, engine)

    # Almacenar el DataFrame en una tabla de la base de datos
    result_df.to_sql('department_hiring_report', engine, if_exists='replace', index=False)

    return result_df

# Configuración de la base de datos
DATABASE_CONFIG = {
    'Server': 'SANTIOC\BDSANTI',
    'Database': 'Globantest',
    'Trusted_Connection': 'yes'  #  autenticación de Windows
}

# Generar el informe de contratación por departamento y almacenarlo en una tabla
report_df = generate_department_hiring_report(DATABASE_CONFIG)

# Imprimir el DataFrame con el informe
print(report_df)
