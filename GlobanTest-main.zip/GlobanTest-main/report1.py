import pandas as pd
from sqlalchemy import create_engine

def generate_hired_employees_summary(DATABASE_CONFIG):
    # Creo la cadena de conexión
    conn_str = (
        f"mssql+pyodbc://{DATABASE_CONFIG['Server']}/{DATABASE_CONFIG['Database']}?"
        f"trusted_connection={DATABASE_CONFIG['Trusted_Connection']}&"
        "driver=ODBC+Driver+17+for+SQL+Server"
    )

    # Creo la conexión al motor SQLAlchemy
    engine = create_engine(conn_str)

    # Definó la consulta SQL para generar el resumen de empleados contratados
    sql_query = """
        SELECT
            departments.Department,
            jobs.Job,
            SUM(CASE WHEN hired_employees.Datetime >= '2021-01-01' AND hired_employees.Datetime < '2021-04-01' THEN 1 ELSE 0 END) AS Q1,
            SUM(CASE WHEN hired_employees.Datetime >= '2021-04-01' AND hired_employees.Datetime < '2021-07-01' THEN 1 ELSE 0 END) AS Q2,
            SUM(CASE WHEN hired_employees.Datetime >= '2021-07-01' AND hired_employees.Datetime < '2021-10-01' THEN 1 ELSE 0 END) AS Q3,
            SUM(CASE WHEN hired_employees.Datetime >= '2021-10-01' AND hired_employees.Datetime < '2022-01-01' THEN 1 ELSE 0 END) AS Q4
        FROM
            hired_employees
        INNER JOIN
            departments ON hired_employees.Department_id = departments.ID
        INNER JOIN
            jobs ON hired_employees.Job_id = jobs.ID
        WHERE
            hired_employees.Datetime >= '2021-01-01' AND hired_employees.Datetime < '2022-01-01'
        GROUP BY
            departments.Department, jobs.Job
        ORDER BY
            departments.Department, jobs.Job
    """

    # Ejecutar la consulta SQL y almacenar los resultados en un DataFrame
    result_df = pd.read_sql_query(sql_query, engine)

    # Almacenar el DataFrame en una tabla de la base de datos
    result_df.to_sql('hired_employees_summary', engine, if_exists='replace', index=False)

    return result_df

# Configuración de la base de datos
DATABASE_CONFIG = {
    'Server': 'SANTIOC\BDSANTI',
    'Database': 'Globantest',
    'Trusted_Connection': 'yes'  #  autenticación de Windows
}

# Generar el resumen de empleados contratados y almacenarlo en una tabla
summary_df = generate_hired_employees_summary(DATABASE_CONFIG)

# Imprimir el DataFrame con el resumen
print(summary_df)
